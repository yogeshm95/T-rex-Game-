# chrome-dino-game

A simple Java implementation of the offline Chrome jumping T-Rex game.
In order to run this, compile all the \*.java files and start from class UserInterface.

![Moment of jump](https://github.com/nabhoneel/chrome-dino-game/raw/master/Screenshot%202018-11-30%2017.49.33.png)
![Just died, eyes widened due to shock](https://github.com/nabhoneel/chrome-dino-game/raw/master/Screenshot%202018-11-30%2017.49.43.png)
